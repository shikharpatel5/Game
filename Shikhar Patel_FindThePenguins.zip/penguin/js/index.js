 var Score = 0;

$(document).ready( function() {
    
    var Score = 0;
    document.getElementById("score").innerHTML = "Score:" + Score ;

    //This code will run after your page loads

    var parent = $("#Jumble");
    var divs = parent.children();
    while (divs.length) {
    parent.append(divs.splice(Math.floor(Math.random() * divs.length), 1)[0]);
    }
    
    Game();
});

function Game(){

    $('#penguin1').click(function () {
        document.getElementById("penguin1").innerHTML = '<img src= "css/images/penguin_1.png">' + '<audio id="audio" src="https://www.soundjay.com/button/sounds/button-4.mp3" autoplay="false" ></audio>';
        Score++;
        document.getElementById("score").innerHTML = "Score:" + Score ;
        function playSound() {
          var sound = document.getElementById("audio");
          sound.play();
      }
    });
    
     $('#penguin2').click(function () {
        document.getElementById("penguin2").innerHTML = '<img src= "css/images/penguin_2.png">' + '<audio id="audio" src="https://www.soundjay.com/button/sounds/button-4.mp3" autoplay="false" ></audio>';
         Score++;
        document.getElementById("score").innerHTML = "Score:" + Score ;
         function playSound() {
          var sound = document.getElementById("audio");
          sound.play();
      }
    });
    
     $('#penguin3').click(function () {
        document.getElementById("penguin3").innerHTML = '<img src= "css/images/penguin_3.png">' + '<audio id="audio" src="https://www.soundjay.com/button/sounds/button-4.mp3" autoplay="false" ></audio>';
         Score++;
        document.getElementById("score").innerHTML = "Score:" + Score ;
          function playSound() {
          var sound = document.getElementById("audio");
          sound.play();
      }
    });
    
     $('#penguin4').click(function () {
        document.getElementById("penguin4").innerHTML = '<img src= "css/images/penguin_4.png">' + '<audio id="audio" src="https://www.soundjay.com/button/sounds/button-4.mp3" autoplay="false" ></audio>';
         Score++;
        document.getElementById("score").innerHTML = "Score:" + Score ;
          function playSound() {
          var sound = document.getElementById("audio");
          sound.play();
      }
    });
    
     $('#penguin5').click(function () {
        document.getElementById("penguin5").innerHTML = '<img src= "css/images/penguin_5.png">' + '<audio id="audio" src="https://www.soundjay.com/button/sounds/button-4.mp3" autoplay="false" ></audio>';
         Score++;
        document.getElementById("score").innerHTML = "Score:" + Score ;
          function playSound() {
          var sound = document.getElementById("audio");
          sound.play();
      }
    });
    
     $('#penguin6').click(function () {
        document.getElementById("penguin6").innerHTML = '<img src= "css/images/penguin_6.png">' + '<audio id="audio" src="https://www.soundjay.com/button/sounds/button-4.mp3" autoplay="false" ></audio>';
         Score++;
        document.getElementById("score").innerHTML = "Score:" + Score ;
          function playSound() {
          var sound = document.getElementById("audio");
          sound.play();
      }
    });
    
     $('#penguin7').click(function () {
        document.getElementById("penguin7").innerHTML = '<img src= "css/images/penguin_7.png">' + '<audio id="audio" src="https://www.soundjay.com/button/sounds/button-4.mp3" autoplay="false" ></audio>';
         Score++;
        document.getElementById("score").innerHTML = "Score:" + Score ;
          function playSound() {
          var sound = document.getElementById("audio");
          sound.play();
      }
    });
    
     $('#penguin8').click(function () {
        document.getElementById("penguin8").innerHTML = '<img src= "css/images/penguin_8.png">' + '<audio id="audio" src="https://www.soundjay.com/button/sounds/button-4.mp3" autoplay="false" ></audio>';
         Score++;
        document.getElementById("score").innerHTML = "Score:" + Score ;
          function playSound() {
          var sound = document.getElementById("audio");
          sound.play();
      }
    });
    
     $('#yeti').click(function () {
        document.getElementById("yeti").innerHTML = '<img src= "css/images/yeti.png">' + '<audio id="audio" src="https://www.soundjay.com/button/sounds/button-8.mp3" autoplay="false" ></audio>';
         
          function playSound() {
          var sound = document.getElementById("audio");
          sound.play();
      }
         
         alert("You Loose!  Try Again");
        setTimeout(function(){ location.reload(); }, 1000);
    });
    
    
} 